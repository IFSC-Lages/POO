/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula6;

import java.time.LocalDate;
import java.time.Period;

/**
 *
 * @author Lidiane Visintin
 */
class Emprestimo {
    private Livro livro;
    private LocalDate dataEmprestimo;
    private LocalDate dataDevolucao;

    public Emprestimo(Livro livro, LocalDate dataEmprestimo) {
        this.livro = livro;
        this.dataEmprestimo = dataEmprestimo;
        this.dataDevolucao = dataEmprestimo.plusDays(14);
    }

    public boolean estaAtrasado() {
        return LocalDate.now().isAfter(dataDevolucao);
    }

    public long diasDeAtraso() {
        if (estaAtrasado()) {
            return Period.between(dataDevolucao, LocalDate.now()).getDays();
        }
        return 0;
    }

    @Override
    public String toString() {
        return "Livro: " + livro + "\nData de Empréstimo: " + dataEmprestimo +
               "\nData de Devolução: " + dataDevolucao;
    }
}

