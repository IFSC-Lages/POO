/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula6;

/**
 *
 * @author Lidiane Visintin
 */
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;

class Evento {
    private String titulo;
    private LocalDateTime data;
    private String local;

    public Evento(String titulo, LocalDateTime data, String local) {
        this.titulo = titulo;
        this.data = data;
        this.local = local;
    }

    public boolean jaAconteceu() {
        return data.isBefore(LocalDateTime.now());
    }

    public long diasRestantes() {
       return Period.between(LocalDate.now(), data.toLocalDate()).getDays();
    }

    public String resumo() {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        return "Evento: " + titulo + " - Local: " + local + "\nData: " + data.format(fmt);
    }
}


