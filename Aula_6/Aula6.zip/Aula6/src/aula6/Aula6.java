/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aula6;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 *
 * @author Lidiane Visintin
 */
public class Aula6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       //Pessoa p1 = new Pessoa("Ana", LocalDate.of(2000, 5, 10));
       LocalDate dataNascimento =  LocalDate.of(2000, 5, 10);
       Pessoa p1 = new Pessoa("Ana", dataNascimento);
       System.out.print(p1.toString());
       
       Pessoa p2 = new Pessoa("Carlos", LocalDate.of(1995, 11, 25));
       System.out.print(p2.toString());
    
        Evento e1 = new Evento("Show de Talentos", LocalDateTime.of(2025, 10, 5, 20, 0), "Ginásio Municipal");
        Evento e2 = new Evento("Congresso de TI", LocalDateTime.of(2023, 9, 10, 9, 0), "Centro de Convenções");

        System.out.println("\n" + e2.resumo());
        System.out.println("Já aconteceu? " + e1.jaAconteceu());
        System.out.println("Dias restantes: " + e1.diasRestantes());

        System.out.println("\n" + e2.resumo());
        System.out.println("Já aconteceu? " + e2.jaAconteceu());
        System.out.println("Dias restantes: " + e2.diasRestantes());
    
        Livro livro = new Livro("Java: Como Programar", "Deitel", 2016);
        Emprestimo emprestimo = new Emprestimo(livro, LocalDate.of(2025, 8, 20));

        System.out.println("Empréstimo:"+emprestimo);
        System.out.println("Está atrasado? " + emprestimo.estaAtrasado());
        System.out.println("Dias de atraso: " + emprestimo.diasDeAtraso());
    
    
    }
    
}
