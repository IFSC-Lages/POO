/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package colegio;

/**
 *
 * @author alunolages
 */
public class Disciplina {
    int codDisciplina;
    String curso;

    public Disciplina(int codDisciplina, String curso) {
        this.codDisciplina = codDisciplina;
        this.curso = curso;
    }

    public int getCodDisciplina() {
        return codDisciplina;
    }

    public void setCodDisciplina(int codDisciplina) {
        this.codDisciplina = codDisciplina;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    @Override
    public String toString() {
        return "Disciplina{" + "codDisciplina=" + codDisciplina + ", curso=" + curso + '}';
    }
    
    
    
    
}
