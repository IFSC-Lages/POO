/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package colegio;

import java.util.ArrayList;

/**
 *
 * @author alunolages
 */
public class Professor {
    String nome, graduacao;
    int id;
    private ArrayList <Disciplina> disciplinasDocente;

    public Professor(String nome, String graduacao, int id) {
        this.nome = nome;
        this.graduacao = graduacao;
        this.id = id;
    }

    public Professor(String nome, String graduacao, int id, ArrayList<Disciplina> disciplinasDocente) {
        this.nome = nome;
        this.graduacao = graduacao;
        this.id = id;
        this.disciplinasDocente = disciplinasDocente;
    }
    

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getGraduacao() {
        return graduacao;
    }

    public void setGraduacao(String graduacao) {
        this.graduacao = graduacao;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Professor{" + "nome=" + nome + ", graduacao=" + graduacao + ", id=" + id + ", disciplinasDocente=" + disciplinasDocente + '}';
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
