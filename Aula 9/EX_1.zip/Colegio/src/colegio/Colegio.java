/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package colegio;

import java.util.ArrayList;

/**
 *
 * @author alunolages
 */
public class Colegio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int nome;
       Disciplina d1 = new Disciplina(980, "Letras");
       Disciplina d2 = new Disciplina(970, "CC");
       
       ArrayList <Disciplina> disciplinasDocente = new ArrayList();
       
       disciplinasDocente.add(d1);
       disciplinasDocente.add(d2);
       
       Professor professora = new Professor("Lidiane", "CC", 123, disciplinasDocente);
        System.out.println("" + professora.toString());
       
    }
    
}
