import java.time.LocalDate;
import java.util.ArrayList;


public class Executa {

   
    public static void main(String[] args) {
        ArrayList<Jogador> lista = new ArrayList();
        
        Jogador jogador1 = new Jogador("Romário","Atacante",11);
        System.out.println(jogador1.toString());
        lista.add( jogador1 ); //add final
        
        Jogador jogador2 = new Jogador("Edmundo","Atacante",9);
        System.out.println(jogador2.toString());
        lista.add( jogador2 ); // 0 1a posicao ArrayList
        
        Jogador jogador3 = new Jogador("Juca","Atacante",10);
        System.out.println(jogador3.toString());
        lista.add(0, jogador3 ); // 0 10a posicao ArrayList
        
        System.out.println("Lista="+lista);
        
        Time time = new Time("Vasco", LocalDate.of(1900, 1, 10));
       
        //Time time1 = new Time("Vasco", LocalDate.of(1900, 1, 10), lista);
        
        time.associaListaJogadores( lista );
        
        System.out.println( time.toString() );
        
        System.out.println("Total: " + time.getListaJogadores().size() );
        
        if (time.getListaJogadores().isEmpty()) {
            System.out.println("Lista vazia!");
        } else {
            System.out.println("Lista NÃO vazia!");
        }
        
        //Jogador j = time.getListaJogadores().get(0);
        //System.out.println( j.toString() );
        
        //time.getListaJogadores().remove(0);
        
        // opcao 1
        int n = time.getListaJogadores().size();
        for (int i = 0; i < n; i++) {
            System.out.println( time.getListaJogadores().get(i) );
        }
        
        // opcao 2 foreach
        for (Jogador objetoJogador:time.getListaJogadores()) {
            System.out.println( objetoJogador );
        }
    }
    
}
