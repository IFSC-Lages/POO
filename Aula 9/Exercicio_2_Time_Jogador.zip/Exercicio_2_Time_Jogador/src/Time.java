
import java.time.LocalDate;
import java.util.ArrayList;

public class Time {
    private String nome;
    private LocalDate dataFundacao;
    
    private ArrayList<Jogador> listaJogadores;

    public Time(String nome, LocalDate dataFundacao) {
        this.nome = nome;
        this.dataFundacao = dataFundacao;
    }

    public Time(String nome, LocalDate dataFundacao, ArrayList<Jogador> listaJogadores) {
        this.nome = nome;
        this.dataFundacao = dataFundacao;
        this.listaJogadores = listaJogadores;
    }
    

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public LocalDate getDataFundacao() {
        return dataFundacao;
    }

    public void setDataFundacao(LocalDate dataFundacao) {
        this.dataFundacao = dataFundacao;
    }

    public ArrayList<Jogador> getListaJogadores() {
        return listaJogadores;
    }
    
    public void associaListaJogadores(ArrayList<Jogador> listaJogadores) {
        this.listaJogadores = listaJogadores;
    }

    @Override
    public String toString() {
        return "Time{" + "nome=" + nome + ", dataFundacao=" + dataFundacao + ", listaJogadores=" + listaJogadores + '}';
    }
    
    
    
    
}
