/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicios_polimorfismo;

import java.util.ArrayList;

/**
 *
 * @author Lidiane Visintin
 */
public class Exercicios_polimorfismo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Calculadora calc = new Calculadora();

        int somaInt = calc.somar(10, 20);
        double somaDouble = calc.somar(10.5, 20.8);
        int somaTres = calc.somar(3, 4, 5);

        System.out.println("Somar(int, int): " + somaInt);
        System.out.println("Somar(double, double): " + somaDouble);
        System.out.println("Somar(int, int, int): " + somaTres);

        
        
    /* Questão 2 */
    
        Funcionario f1 = new Funcionario("João", 3000.00);
        Funcionario g1 = new Gerente("Maria", 5000.00); // Polimorfismo

        System.out.println("Funcionário: " + f1.getNome() +
                " | Bônus: R$ " + f1.calcularBonus());

        System.out.println("Gerente: " + g1.getNome() +
                " | Bônus: R$ " + g1.calcularBonus());
    
    
    /* Questão 3 */
    
        ArrayList<Pagamento> pagamentos = new ArrayList<>();

        pagamentos.add(new PagamentoCartao());
        pagamentos.add(new PagamentoPix());
        pagamentos.add(new PagamentoBoleto());
        pagamentos.add(new Pagamento());

        double[] valores = {100.0, 250.5, 80.0, 20.0};

        // Processando pagamentos de forma polimórfica
        for (int i = 0; i < pagamentos.size(); i++) {
            Pagamento p = pagamentos.get(i);
            System.out.println(pagamentos.get(i));
            p.processarPagamento(valores[i]);
        }
    }
}
