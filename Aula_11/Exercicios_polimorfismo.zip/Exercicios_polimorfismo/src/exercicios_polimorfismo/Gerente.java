/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicios_polimorfismo;

/**
 *
 * @author Lidiane Visintin
 */
public class Gerente extends Funcionario {

    public Gerente(String nome, double salario) {
        super(nome, salario);
    }

    @Override
    public double calcularBonus() {
        return super.calcularBonus() * 2; // retorna 20% (duas vezes 10%)
        // ou poderia ser: return getSalario() * 0.20 se o salário estiver implementado na superclasse Funcionario;
    }
}
