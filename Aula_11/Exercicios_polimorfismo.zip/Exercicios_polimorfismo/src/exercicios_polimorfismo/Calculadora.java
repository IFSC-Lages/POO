/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicios_polimorfismo;

/**
 *
 * @author Lidiane Visintin
 */
public class Calculadora {
    // somar dois inteiros
    public int somar(int a, int b) {
        return a + b;
    }

    // somar dois números double
    public double somar(double a, double b) {
        return a + b;
    }

    // somar três inteiros
    public int somar(int a, int b, int c) {
        return a + b + c;
    }
}

