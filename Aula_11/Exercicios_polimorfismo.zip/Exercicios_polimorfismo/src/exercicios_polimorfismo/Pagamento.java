/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicios_polimorfismo;

/**
 *
 * @author Lidiane Visintin
 */
public class Pagamento {
    public void processarPagamento(double valor) {
        System.out.println("Processando pagamento de R$" + valor);
    }
}

