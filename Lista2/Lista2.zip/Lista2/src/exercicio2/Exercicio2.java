/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio2;

import java.util.ArrayList;

/**
 *
 * @author Lidiane Visintin
 */
public class Exercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Jogador> jogadores = new ArrayList<>();
        jogadores.add(new Jogador("Pedro", "Atacante"));
        jogadores.add(new Jogador("Lucas", "Goleiro"));
        jogadores.add(new Jogador("Rafael", "Zagueiro"));
        jogadores.add(new Jogador("Carlos", "Atacante"));
        jogadores.add(new Jogador("Bruno", "Meio-Campo"));

        // a) Mostrar todos os jogadores (for-each)
        System.out.println("a) Lista de jogadores:");
        for (Jogador j : jogadores) {
            System.out.println(j);
        }

        // b) Total
        System.out.println("\nb) Total de jogadores: " + jogadores.size());

        // c) Somente atacantes
        System.out.println("\nc) Jogadores atacantes:");
        for (Jogador j : jogadores) {
            if (j.getPosicao().equalsIgnoreCase("Atacante")) {
                System.out.println(j);
            }
        }

        // d) Quarto jogador
        System.out.println("\nd) Quarto jogador: " + jogadores.get(3));
    }
    
}
