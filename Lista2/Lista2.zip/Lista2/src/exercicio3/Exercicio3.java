/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio3;

import java.util.ArrayList;

/**
 *
 * @author Lidiane Visintin
 */
public class Exercicio3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Conta> contas = new ArrayList<>();
        contas.add(new Conta(101, 500));
        contas.add(new Conta(111, -20));
        contas.add(new Conta(222, 1000));
        contas.add(new Conta(333, -50));

        // a) Total de contas
        System.out.println("a) Total de contas: " + contas.size());

        // b) Conta com maior saldo
        //pega a informação da primeira para ter com quem comparar
        Conta maior = contas.get(0);
        for (Conta c : contas) {
            if (c.getSaldo() > maior.getSaldo()) {
                maior = c;
            }
        }
        System.out.println("\nb) Conta com maior saldo: " + maior);

        // c) Contas com saldo negativo
        int totalNegativas = 0;
        for (Conta c : contas) {
            if (c.getSaldo() < 0){
                totalNegativas++;
            }
        }
        System.out.println("\nc) Total de contas negativas: " + totalNegativas);

        // d) Verificar conta 111
        boolean encontrada = false;
        for (Conta c : contas) {
            if (c.getNumero() == 111) {
                System.out.println("\nd) Conta 111 encontrada: " + c);
                encontrada = true;
            }
        }
        if (!encontrada){ 
            System.out.println("\nConta 111 não encontrada.");
        }

    }
    
}
