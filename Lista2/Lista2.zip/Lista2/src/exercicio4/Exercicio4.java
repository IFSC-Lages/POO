/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio4;

import java.util.ArrayList;

/**
 *
 * @author Lidiane Visintin
 */
public class Exercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Produto> produtos = new ArrayList<>();
        produtos.add(new Produto(101, "Arroz", 25.0));
        produtos.add(new Produto(102, "Feijão", 12.5));
        produtos.add(new Produto(103, "Café", 18.0));
        produtos.add(new Produto(111, "Carne", 120.0));
        produtos.add(new Produto(115, "Vinho", 150.0));

        // a) Mostrar produtos
        System.out.println("a) Lista de produtos:");
        for (Produto p : produtos) {
            System.out.println(p);
        }

        // b) Total com preço > 100
        int cont = 0;
        for (Produto p : produtos) {
            if (p.getPreco() > 100){ 
                cont++;
            }
        }
        System.out.println("\nb) Produtos com preço > 100: " + cont);

        // c) Produto código 111
        boolean existe = false;
        for (Produto p : produtos) {
            if (p.getCodigo() == 111) {
                System.out.println("\nc) Produto com código 111 encontrado: " + p);
                existe = true;
            }
        }
        if (!existe){
            System.out.println("\nc) Produto com código 111 não encontrado.");
        }
    }
    
}
