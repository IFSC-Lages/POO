/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio1;

import java.util.ArrayList;

/**
 *
 * @author Lidiane Visintin
 */
public class Exercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Contato> contatos = new ArrayList<>();

        // Inserindo contatos
        contatos.add(new Contato("João", "99999-0001"));
        contatos.add(new Contato("Maria", "99999-0002"));
        contatos.add(new Contato("Carlos", "99999-0003"));
        contatos.add(new Contato("Julia", "99999-0004"));
        contatos.add(new Contato("Paulo", "99999-0005"));

        // a) Número de contatos
        System.out.println("a) Total de contatos: " + contatos.size());

        // b) Todos os contatos
        System.out.println("\nb) Contatos cadastrados:");
        for (Contato c : contatos) {
            System.out.println(c);
        }

        // c) Segundo contato
        System.out.println("\nc) Segundo contato: " + contatos.get(1));

        // d) Lista vazia?
        System.out.println("\nd) Lista está vazia? " + contatos.isEmpty());

        // e) Remover o primeiro
        contatos.remove(0);
        System.out.println("\ne) Primeiro contato removido. Lista agora:");
        for (Contato c : contatos) {
            System.out.println(c);
        }

        // f) Inserir um novo na primeira posição
        contatos.add(0, new Contato("Rafaela", "88888-0000"));
        System.out.println("\nf) Contato adicionado na primeira posição:");
        for (Contato c : contatos) {
            System.out.println(c);
        }

        // g) Atualizar o quarto contato
        if (contatos.size() >= 4) {
            contatos.set(3, new Contato("Ana", "12345"));
        }
        System.out.println("\ng) Quarto contato atualizado:");
        for (Contato c : contatos) {
            System.out.println(c);
        }
    }
    
}
