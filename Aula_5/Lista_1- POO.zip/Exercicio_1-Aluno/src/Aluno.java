public class Aluno {
    private String nome;
    private float nota;
    private int matricula;
    private float peso;
    private float altura;
    
    
    // construtures
    public Aluno() {
        
    }

    public Aluno(String nome, float nota, int matricula) {
        this.nome = nome;
        this.nota = nota;
        this.matricula = matricula;
    }

    public Aluno(String nome, float nota, int matricula, float peso, float altura) {
        this.nome = nome;
        this.nota = nota;
        this.matricula = matricula;
        this.peso = peso;
        this.altura = altura;
    }
    
    //
    public float getNota() {
        return nota;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setNota(float nota) {
        this.nota = nota;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        if (peso > 0)
            this.peso = peso;
        else 
            this.peso = 0;
    }

    public float getAltura() {
        return altura;
    }

    public void setAltura(float altura) {
        if (altura >0 && altura <= 3)
            this.altura = altura;
        else
            this.altura = 0;
    }

    @Override
    public String toString() {
        return "Aluno{" + "nome=" + nome + ", peso=" + peso + ", altura=" + altura + '}';
    }
    
}
