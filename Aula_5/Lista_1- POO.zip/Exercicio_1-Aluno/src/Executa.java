
import java.util.Scanner;

public class Executa {
    public static void main(String[] args) {
        Aluno aluno1 = new Aluno();
        System.out.println(aluno1.toString());
        
        Aluno aluno2 = new Aluno("Ana", 9f, 1234);
        System.out.println(aluno2.toString());
        
        Scanner entrada = new Scanner(System.in);
        String nome = entrada.next();
        aluno2.setNome(nome);
        
        float altura = entrada.nextFloat();
        aluno2.setAltura(altura);
        float peso = entrada.nextFloat();
        aluno2.setPeso(peso);
        
        System.out.println(aluno2.toString());
      
   
    }
    
}
