public class Graus {
    private float grausCelsius;
    private float grausFahrenheit;
    private float grausKelvin;
 

    public Graus() {
    }
    
    public float getGrausKelvin() {
        return grausKelvin;
    }

    public void setGrausKelvin(float grausKelvin) {
        this.grausKelvin = grausKelvin;
    }

    public float getGrausCelsius() {
        return grausCelsius;
    }

    public void setGrausCelsius(float grausCelsius) {
        this.grausCelsius = grausCelsius;
    }

    public float getGrausFahrenheit() {
        return grausFahrenheit;
    }

    public void setGrausFahrenheit(float grausFahrenheit) {
        this.grausFahrenheit = grausFahrenheit;
    }
    
    public void converteCelsiusParaFahrenheit() {
        this.grausFahrenheit = (this.grausCelsius * 9/5) + 32;
    }
    
    public void converteCelsiusParaKelvin() {
        this.grausKelvin = this.grausCelsius + 273.15f;
    }

    @Override
    public String toString() {
        return "Graus{" + "grausCelsius=" + grausCelsius + ", grausFahrenheit=" + grausFahrenheit + ", grausKelvin=" + grausKelvin + '}';
    }


    
}
