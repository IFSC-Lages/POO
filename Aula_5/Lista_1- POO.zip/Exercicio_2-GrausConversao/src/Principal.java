
import javax.swing.JOptionPane;

public class Principal {
    public static void main(String[] args) {
        Graus graus = new Graus();
        graus.setGrausCelsius(32);
        graus.converteCelsiusParaFahrenheit();
        graus.converteCelsiusParaKelvin();
        JOptionPane.showMessageDialog(null, graus.toString());
    }
    
}
