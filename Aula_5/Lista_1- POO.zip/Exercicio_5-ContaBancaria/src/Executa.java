
import javax.swing.JOptionPane;

public class Executa {
    
    public static void main(String[] args) {
        Conta conta = new Conta("Juca", "1234", 0);
        
        conta.deposito(100);
        JOptionPane.showMessageDialog(null, "Depósito: " + conta.toString());
        
        conta.saque(70);
        JOptionPane.showMessageDialog(null, "Saque: " + conta.toString());
        
        conta.saque(20);
        JOptionPane.showMessageDialog(null, "Saque: " + conta.toString());
        
        conta.saque(900);
        JOptionPane.showMessageDialog(null, "Saque: " + conta.toString());
    }
    
}
