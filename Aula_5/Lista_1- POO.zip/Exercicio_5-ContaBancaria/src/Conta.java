
import javax.swing.JOptionPane;


public class Conta {
    private String nome;
    private String numero;
    private float saldo;
    private float iof;


    public Conta(String nome, String numero, float saldo) {
        this.nome = nome;
        this.numero = numero;
        this.saldo = saldo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public float getSaldo() {
        return saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }
    
    public void deposito(float valor) {
        if (valor > 0) {
            this.saldo = this.saldo + valor;
        }
    }
    
    public void saque(float valor){
        this.iof = 0;
        float valorTotal = calcularIOF(valor) + valor;
        
        if ( getSaldo() >= valorTotal ) {
            this.saldo = this.saldo - valorTotal;
        }else{
            JOptionPane.showMessageDialog(null, "Saldo Induficiente!");
        }
        
    }
    
    private float calcularIOF(float valor){
        float imposto = (valor * 0.1f);
        this.iof = this.iof + imposto;
        
        if (imposto  > 5)
            this.iof = 5;
        
        return this.iof;    
    }

    @Override
    public String toString() {
        return "Conta{" + "nome=" + nome + ", numero=" + numero + ", saldo=" + saldo + ", iof=" + iof + '}';
    }

}
