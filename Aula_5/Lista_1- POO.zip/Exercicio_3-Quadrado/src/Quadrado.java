
import java.util.Scanner;

public class Quadrado {
    Scanner sc = new Scanner(System.in);
    private float lado;
    private float area;
    private float perimetro;
    
    public Quadrado() {
    }

    public Quadrado(float lado) {
        setLado(lado);
    }

    public float getLado() {
        return lado;
    }

    public void setLado(float lado) {
        while(lado < 0) {
            System.out.println("Informe um valor válido para o lado");
            lado = sc.nextInt();
        }
            this.lado = lado;
    }

    public float getArea() {
        return area;
    }

    public void calculaArea() {
        if (getLado() > 0)
            this.area = this.lado * this.lado;
        else
            this.area = 0;
    }

    public float getPerimetro() {
        return perimetro;
    }

    public void calulaPerimetro() {
        if (getLado() > 0)
            this.perimetro = 4 * this.lado;
        else
            this.perimetro = 0;
    }

    @Override
    public String toString() {
        return "Quadrado{" + "lado=" + lado + ", area=" + area + ", perimetro=" + perimetro + '}';
    }
   
    
}
