

import javax.swing.JOptionPane;

public class Executa {
    public static void main(String[] args) {
        Quadrado quadrado = new Quadrado();
        // Aqui poderia ser feita a leitura do teclado para ter a iteração do usuário
        quadrado.setLado(10);
        quadrado.calculaArea();
        quadrado.calulaPerimetro();
        JOptionPane.showMessageDialog(null, quadrado.toString(), "Resultado", 1);
        System.out.println(quadrado.toString());
    }
}
