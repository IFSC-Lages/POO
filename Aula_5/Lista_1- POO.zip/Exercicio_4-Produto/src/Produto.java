
public class Produto {
    private String codigo;
    private String nome;
    private float precoCusto;
    private float precoVenda;
    private float imposto;
    
    public Produto() { }

    public Produto(String codigo, String nome, float precoCusto) {
        this.codigo = codigo;
        setPrecoCusto(precoCusto);
    }

    public String getNome() {
        return nome;
    }
    
    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }   

    public float getPrecoCusto() {
        return precoCusto;
    }

    public void setPrecoCusto(float precoCusto) {
        if (precoCusto >= 0) {
            this.precoCusto = precoCusto;
        } else 
            this.precoCusto = 0;
    }

    public float getPrecoVenda() {
        return precoVenda;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
     public float getImposto() {
        return imposto;
    }

    private void calculaImposto() {
        this.imposto = getPrecoVenda() * 1.1f;
    }

    public void calculaPrecoVenda() {
        this.precoVenda = getPrecoCusto() * 30/100 + getPrecoCusto();
        calculaImposto();
    }

    @Override
    public String toString() {
        return "Produto{" + "codigo=" + codigo + ", precoCusto=" + precoCusto + ", precoVenda=" + precoVenda + ", com imposto=" + imposto + '}';
    }

}
