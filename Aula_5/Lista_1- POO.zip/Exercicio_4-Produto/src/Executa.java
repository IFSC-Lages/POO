
import javax.swing.JOptionPane;


public class Executa {
    
    public static void main(String[] args) {
        Produto produto = new Produto("A123", "Bola", 100);
        produto.calculaPrecoVenda();
        
        JOptionPane.showMessageDialog(null, produto.toString());
    }
    
}
