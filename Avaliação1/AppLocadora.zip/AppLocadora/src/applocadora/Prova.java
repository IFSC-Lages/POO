/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package applocadora;

/**
 *
 * @author Lidiane Visintin
 */
public class Prova {
    public static void soma(String n1, String n2, int id1, int id2){
        n1 = n1 + n2;
        id1 = id1 + id2;
    }

    public static void main(String[] args) {
        String n1, n2;
        int id1, id2;
        n1 = new String("Joao ");
        n2 = new String("Silva");
        id1 = 10;
        id2 = 20;

        soma(n1, n2, id1, id2);
        System.out.println("Nome:" + n1 + " Idade:" + id1);
    }

}
