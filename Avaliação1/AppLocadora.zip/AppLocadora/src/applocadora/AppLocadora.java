/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package applocadora;

/**
 *
 * @author Lidiane Visintin
 */
public class AppLocadora {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       // Criando cliente e veículo
        Cliente c = new Cliente("Mariana Silva", "(48) 99999-0000");
        //Veiculo v = new Veiculo("Fiat Uno", "ABC-1234", 2018);

        // Criando aluguel (construtor público)
        Aluguel aluguel = new Aluguel(120.0, 10); // 10 dias, R$120/dia

        System.out.println("Dados do aluguel:");
        System.out.println(aluguel);
        
        //valorBruto() é privado não é acessível
        //System.out.printf("Valor bruto: R$ %.2f%n", aluguel.valorBruto());

        // Aplicando desconto por pagamento à vista (ex.: 10%)
        double totalAVista = aluguel.aplicarDescontoPagamentoAVista("avista", 10.0);
        System.out.printf("Pagamento à vista (10%% desconto): R$ %.2f%n", totalAVista);

        // Aplicando desconto longo prazo (>7 dias -> 5%)
        double totalLongoPrazo = aluguel.aplicarDescontoLongoPrazo("promo_long");
        System.out.printf("Desconto longo prazo (>7 dias) aplicado: R$ %.2f%n", totalLongoPrazo);

        // Pagamento parcelado (3x) com 8% de juros
        aluguel.pagarParcelado(3);

        // Demonstração de uso do construtor privado via método de fábrica
        Aluguel aluguelSimples = new Aluguel(50.0);
        System.out.println("Aluguel criado pelo construtor 2: " + aluguelSimples);
    }
}
