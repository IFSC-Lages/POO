/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package applocadora;

/**
 *
 * @author Lidiane Visintin
 */
// Aluguel.java
public class Aluguel {
    private double valorDiario;
    private int diasAlugados;
    private String tipoPagamento; // e.g. "avista" ou "parcelado"
    private double descontoAplicado; // percentual aplicado (por exemplo 10.0 = 10%)

    // Construtor 
    public Aluguel(double valorDiario, int diasAlugados) {
        this.valorDiario = valorDiario;
        this.diasAlugados = diasAlugados;
        this.tipoPagamento = "nao informado";
        this.descontoAplicado = 0.0;
    }

    // Construtor 
    public Aluguel(double valorDiario) {
        this.valorDiario = valorDiario;
        this.diasAlugados = 1;
        this.tipoPagamento = "nao informado";
    }
     // Getters e setters

    public double getValorDiario() {
        return valorDiario;
    }

    public int getDiasAlugados() {
        return diasAlugados;
    }

    public String getTipoPagamento() {
        return tipoPagamento;
    }

   
    public double getDescontoAplicado() {    
        return descontoAplicado;
    }

    public void setValorDiario(double valorDiario) {
        this.valorDiario = valorDiario;
    }

    public void setDiasAlugados(int diasAlugados) {
        this.diasAlugados = diasAlugados;
    }

    public void setTipoPagamento(String tipoPagamento) {
        this.tipoPagamento = tipoPagamento;
    }

    public void setDescontoAplicado(double descontoAplicado) {
        this.descontoAplicado = descontoAplicado;
    }

    
    // Calcula o valor bruto (sem descontos/juros) método privado
    private double valorBruto() {
        return valorDiario * diasAlugados;
    }

    // c) Método que calcula um percentual de desconto caso seja pago à vista.
    // Recebe tipoPagamento (ex: "avista") e percentual (ex: 10.0 para 10%)
    public double aplicarDescontoPagamentoAVista(String tipoPagamento, double percentual) {
        this.tipoPagamento = tipoPagamento;
        double bruto = valorBruto();
        double desconto = 0.0;
        if ("avista".equalsIgnoreCase(tipoPagamento) || "à vista".equalsIgnoreCase(tipoPagamento)) {
            desconto = percentual;
            setDescontoAplicado(desconto);
            return aplicarDesconto(bruto, desconto);
        } else {
            setDescontoAplicado(0.0);
            return bruto;
        }
    }

    // d) Método que aplica 5% de desconto caso o aluguel seja superior a 7 dias
    // tipoDesconto é apenas para atender enunciado (poderia ser "promo")
    public double aplicarDescontoLongoPrazo(String tipoDesconto) {
        double bruto = valorBruto();
        if (diasAlugados > 7) {
            double desconto = 5.0;
            setDescontoAplicado(desconto);
            return aplicarDesconto(bruto, desconto);
        } else {
            return bruto;
        }
    }

    // e) Pagamento parcelado com 8% de juros, recebendo número de parcelas e exibindo valor de cada.
    // Retorna o valor total com juros. Também imprime as parcelas 
    public double pagarParcelado(int numeroParcelas) {
        double bruto = valorBruto();
        double totalComJuros = bruto * 1.08; // 8% de juros
        double parcela = totalComJuros / numeroParcelas;

        System.out.printf("Pagamento parcelado em %dx: total = R$ %.2f (8%% juros). Valor de cada parcela = R$ %.2f%n",
                numeroParcelas, totalComJuros, parcela);

        // registra que não houve desconto, e sim acrescimo
        setDescontoAplicado(0.0);
        return totalComJuros;
    }

    // f) Exemplo de outro método private utilizado no projeto: aplica desconto percentual a um valor
    private double aplicarDesconto(double valor, double percentual) {
        double descontoValor = valor * (percentual / 100.0);
        return valor - descontoValor;
    }

    @Override
    public String toString() {
        return "Aluguel{"+"valorDiario=" + valorDiario +
                ", diasAlugados=" + diasAlugados +
                ", tipoPagamento='" + tipoPagamento + '\'' +
                ", descontoAplicado=" + descontoAplicado +
                '}';
    }
}

