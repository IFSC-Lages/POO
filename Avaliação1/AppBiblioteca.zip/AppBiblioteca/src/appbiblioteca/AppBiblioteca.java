/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package appbiblioteca;

/**
 *
 * @author Lidiane Visintin
 */
public class AppBiblioteca {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Cliente c = new Cliente("Mariana Silva", "(48) 99999-0000");
        Livro l = new Livro("Dom Casmurro", "Machado de Assis", 1899);

        Emprestimo e = new Emprestimo(10, 2.5); // 10 dias, multa R$2,50/dia

        System.out.println("Dados do empréstimo:");
        System.out.println(e);

        System.out.printf("Valor bruto: R$ %.2f%n", e.valorBruto());

        // Pagamento à vista com 15% desconto
        double avista = e.aplicarDescontoAVista("avista", 15.0);
        System.out.printf("Pagamento à vista (15%% desconto): R$ %.2f%n", avista);

        // Desconto longo prazo (>7 dias → 2%)
        double longoPrazo = e.aplicarDescontoLongoPrazo("prazo");
        System.out.printf("Desconto longo prazo: R$ %.2f%n", longoPrazo);

        // Cliente VIP
        double vip = e.aplicarDescontoClienteVIP("VIP");
        System.out.printf("Cliente VIP (10%% desconto): R$ %.2f%n", vip);

        // Demonstração do construtor 2
        Emprestimo e2 = new Emprestimo(3.0);
        System.out.println("Criado pelo construtor privado via factory: " + e2);
    }
    
}
