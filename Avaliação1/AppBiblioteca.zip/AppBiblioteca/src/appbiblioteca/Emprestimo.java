/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package appbiblioteca;

/**
 *
 * @author Lidiane Visintin
 */
public class Emprestimo {
    private int diasEmprestimo;
    private double multaPorDia;
    private double descontoAplicado;
    private String tipoPagamento;

    // Construtor completo
    public Emprestimo(int diasEmprestimo, double multaPorDia) {
        this.diasEmprestimo = diasEmprestimo;
        this.multaPorDia = multaPorDia;
        this.descontoAplicado = 0.0;
        this.tipoPagamento = "nao informado";
    }

    // Construtor 
    public Emprestimo(double multaPorDia) {
        this.multaPorDia = multaPorDia;
        this.diasEmprestimo = 1;
    }


    // Getters e Setters

    public int getDiasEmprestimo() {
        return diasEmprestimo;
    }

    public double getMultaPorDia() {
        return multaPorDia;
    }

    public double getDescontoAplicado() {
        return descontoAplicado;
    }

    public String getTipoPagamento() {
        return tipoPagamento;
    }

    public void setDiasEmprestimo(int diasEmprestimo) {
        this.diasEmprestimo = diasEmprestimo;
    }

    public void setMultaPorDia(double multaPorDia) {
        this.multaPorDia = multaPorDia;
    }

    public void setDescontoAplicado(double descontoAplicado) {
        this.descontoAplicado = descontoAplicado;
    }

    public void setTipoPagamento(String tipoPagamento) {
        this.tipoPagamento = tipoPagamento;
    }   

    // Calcula valor bruto da multa (dias * multaPorDia)
    public double valorBruto() {
        return diasEmprestimo * multaPorDia;
    }

    // c) Desconto para pagamento à vista
    public double aplicarDescontoAVista(String tipoPagamento, double percentual) {
        this.tipoPagamento = tipoPagamento;
        if ("avista".equalsIgnoreCase(tipoPagamento)) {
            this.descontoAplicado = percentual;
            return aplicarDesconto(valorBruto(), percentual);
        }
        return valorBruto();
    }

    // d) Desconto 2% se > 7 dias
    public double aplicarDescontoLongoPrazo(String tipoDesconto) {
        if (diasEmprestimo > 7) {
            this.descontoAplicado = 2.0;
            return aplicarDesconto(valorBruto(), 2.0);
        }
        return valorBruto();
    }

    // e) Desconto 10% para cliente VIP
    public double aplicarDescontoClienteVIP(String tipoCliente) {
        if ("VIP".equalsIgnoreCase(tipoCliente)) {
            this.descontoAplicado = 10.0;
            return aplicarDesconto(valorBruto(), 10.0);
        }
        return valorBruto();
    }

    // f) Método privado auxiliar
    private double aplicarDesconto(double valor, double percentual) {
        double valorDesc = valor * (percentual / 100.0);
        return valor - valorDesc;
    }

    @Override
    public String toString() {
        return "Emprestimo{" +"diasEmprestimo=" + diasEmprestimo +
                ", multaPorDia=" + multaPorDia +
                ", descontoAplicado=" + descontoAplicado +
                ", tipoPagamento='" + tipoPagamento + '\'' +
                '}';
    }
}
