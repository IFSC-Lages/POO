/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package instituicao;

/**
 *
 * @author Lidiane Visintin
 */
// Classe Curso
public class Curso {
    private String nome;
    private Aluno aluno; // Associação 1-1: Curso tem UM Aluno

    // Construtor
    public Curso(String nome, Aluno aluno) {
        this.nome = nome;
        this.aluno = aluno;
    }

    // Getters e Setters
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Aluno getAluno() {
        return aluno;
    }

    public void setAluno(Aluno aluno) {
        this.aluno = aluno;
    }

    // toString
    @Override
    public String toString() {
        return "Curso{" +
                "nome='" + nome + '\'' +
                ", aluno=" + aluno +
                '}';
    }
}

