/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package instituicao;

/**
 *
 * @author Lidiane Visintin
 */
public class Instituicao {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Criando um aluno
        Aluno a1 = new Aluno("Maria", 101);

        // Criando curso associado a esse aluno
        Curso curso = new Curso("Programação Orientada a Objetos", a1);

        // Exibindo informações
        System.out.println(curso);

        // Alterando o aluno do curso
        Aluno a2 = new Aluno("João", 102);
        curso.setAluno(a2);

        System.out.println(curso);
    }
    
}
