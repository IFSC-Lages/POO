public class Livro {
    private String titulo;
    private int totalPaginas;
    private float peso;
    private Editora editora;

    public Livro(String titulo, int totalPaginas, float peso) {
        this.titulo = titulo;
        this.totalPaginas = totalPaginas;
        this.peso = peso;
    }

    public Livro(String titulo, int totalPaginas, float peso, Editora editora) {
        this.titulo = titulo;
        this.totalPaginas = totalPaginas;
        this.peso = peso;
        this.editora = editora;
    }
    

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getTotalPaginas() {
        return totalPaginas;
    }

    public void setTotalPaginas(int totalPaginas) {
        this.totalPaginas = totalPaginas;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    public Editora getEditora() {
        return editora;
    }

    public void associaEditora(Editora editora) {
        this.editora = editora;
    }

    @Override
    public String toString() {
        return "Livro{" + "titulo=" + titulo + ", totalPaginas=" + totalPaginas + ", peso=" + peso + ", editora=" + editora + '}';
    }
    
    
    
}
