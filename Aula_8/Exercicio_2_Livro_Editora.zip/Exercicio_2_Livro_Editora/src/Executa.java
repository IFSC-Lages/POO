public class Executa {

   
    public static void main(String[] args) {
        
        Editora editora = new Editora("Editora_1", "Rua Sei lá!");
        Editora editora1 = new Editora("Editora_2", "Rua AB!");
        Livro livro = new Livro("POO", 100, 1.5f);
        
        Livro livro1 = new Livro("BD", 200, 1.0f, editora1);
        livro.associaEditora( editora );
        
        System.out.println( livro );
        
        System.out.println( livro.getEditora().getEndereco());
        
        System.out.println( livro1 );
        
        
    }
    
}
