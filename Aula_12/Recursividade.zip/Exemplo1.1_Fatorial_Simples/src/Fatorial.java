public class Fatorial {

    public int fatorial(int n) {

        if (n <= 1) { // solução de parada!
            return 1;
        } else { // soluções parciais
            return n * fatorial(n - 1);
        }

    }
    
    

}