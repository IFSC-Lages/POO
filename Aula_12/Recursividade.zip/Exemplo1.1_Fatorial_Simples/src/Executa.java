
public class Executa {

    
    public static void main(String[] args) {

        Fatorial fat = new Fatorial();
        int n = 10;
        
        int valorFatorial = fat.fatorial( n );
        System.out.println(n + " fatorial é: " + valorFatorial); 
        
       
    }  
    
}
