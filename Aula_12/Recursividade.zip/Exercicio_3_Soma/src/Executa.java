public class Executa {

    
    public static void main(String[] args) {
        Soma soma = new Soma();
        
        for (int i = 1; i <= 10; i++) {
            int valorSoma = soma.soma( i );
            System.out.println("O valor da soma de " + i + " é: " + valorSoma);
        }
        
        // iterativa
        for (int i = 1; i <= 10; i++) {
            int valorSoma = soma.somaIterativa( i );
            System.out.println("O valor da soma de " + i + " é: " + valorSoma);
           
        }
    }
    
}
