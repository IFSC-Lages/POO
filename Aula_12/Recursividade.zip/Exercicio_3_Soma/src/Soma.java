public class Soma {
    
    public int soma(int n) {
        if (n == 1)
            return 1;
        else 
            return n + soma(n-1);
    }
    
    public int somaIterativa(int n) {
        
        int soma = 0;
        for (int i = 1; i <= n; i++) {
            soma = soma + i;
        }
        return soma;
    }

}
