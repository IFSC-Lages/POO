/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicio_3_decrescente;

/**
 *
 * @author Lidiane Visintin
 */
public class ImprimeDecrescente {
    
        public static void imprimirDecrescente(int n) {
        // Caso base: quando chega a zero, a recursão para
        if (n == 0) {
            return;
        }

        // Ação: imprime o número atual
        System.out.println(n);

        // Chamada recursiva: chama o método com o número anterior
        imprimirDecrescente(n - 1);
    }
    
}
