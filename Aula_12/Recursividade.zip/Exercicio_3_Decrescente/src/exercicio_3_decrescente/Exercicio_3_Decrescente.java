/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio_3_decrescente;

/**
 *
 * @author Lidiane Visintin
 */
public class Exercicio_3_Decrescente {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       //ImprimeDecrescente p = new ImprimeDecrescente();
       //p.imprimirDecrescente(10);
       ImprimeDecrescente.imprimirDecrescente(10);
        
    }
    
}
