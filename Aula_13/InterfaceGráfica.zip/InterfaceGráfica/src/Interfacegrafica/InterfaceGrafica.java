/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Interfacegrafica;

/**
 *
 * @author Lidiane Visintin
 */
public class InterfaceGrafica {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Tela1 j = new Tela1();
        j.setLocationRelativeTo(null); //Seta a posição inicial da janela para o centro da tela.
        j.setVisible(true);
//          Tela2 tela = new Tela2();
//          tela.setVisible(true);
    }
    
}
