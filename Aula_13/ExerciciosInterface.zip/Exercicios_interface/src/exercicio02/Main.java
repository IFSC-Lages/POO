package exercicio02;

public class Main {
    public static void main(String args[]){
        Contador j = new Contador();
        j.setLocationRelativeTo(null); //Seta a posição inicial da janela para o centro da tela.
        j.setVisible(true);
    }
}
