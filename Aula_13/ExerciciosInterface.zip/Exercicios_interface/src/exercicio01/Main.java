package exercicio01;

public class Main {
    public static void main(String[] args) {
        TelaExercico1 j = new TelaExercico1();
        j.setLocationRelativeTo(null); //Seta a posição inicial da janela para o centro da tela.
        j.setVisible(true);
    }
}
