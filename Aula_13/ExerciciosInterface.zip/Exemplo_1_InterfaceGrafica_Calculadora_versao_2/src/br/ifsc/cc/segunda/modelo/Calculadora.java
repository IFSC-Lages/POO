package br.ifsc.cc.segunda.modelo;

public class Calculadora {
    
    public Calculadora() {       
    }

    public float soma(float valor1, float valor2){
        return valor1 + valor2;
    }
    
    public float subtrai(float valor1, float valor2){
        return valor1 - valor2;
    }
    
    public float multiplica(float valor1, float valor2){
        return valor1 * valor2;
    }
    
    public float divide(float valor1, float valor2){
        return valor1 / valor2;
    }
    
}
